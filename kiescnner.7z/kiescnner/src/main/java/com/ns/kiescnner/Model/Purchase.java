package com.ns.kiescnner.Model;

public class Purchase {
    private String orderNumber;

    private float cc;

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public float getCc() {
        return cc;
    }

    public void setCc(float cc) {
        this.cc = cc;
    }

    public Purchase(String orderNumber, float cc) {
        this.orderNumber = orderNumber;
        this.cc = cc;
    }

    public Purchase() {
    }

    @Override
    public String toString() {
        return "Purchase{" +
                "orderNumber='" + orderNumber + '\'' +
                ", cc=" + cc +
                '}';
    }
}
