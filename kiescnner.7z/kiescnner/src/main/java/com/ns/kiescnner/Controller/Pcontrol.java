package com.ns.kiescnner.Controller;

import com.ns.kiescnner.Model.Purchase;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
@RequestMapping("/api")
public class Pcontrol {


    @GetMapping("/process")
    public void processData() throws IOException {

        KieServices ks = KieServices.Factory.get();
        KieContainer kcontainer = ks.getKieClasspathContainer();
        KieSession ksession = kcontainer.newKieSession("ksession-rule");


        Purchase pp = new Purchase();
        pp.setCc(10);
        ksession.insert(pp);
        int i = ksession.fireAllRules();
        System.out.println("Total Rules fires" + i);




    }

}
