package com.ns.kiescnner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KiescnnerApplication {

	public static void main(String[] args) {
		SpringApplication.run(KiescnnerApplication.class, args);
	}

}
